let map;
let mobileMap;
let markers = [];
let mobileMarkers = [];
let markersByRoute = {}; // Global markers object for route access
let polylines = {};
let directionsService, directionsRenderer;
const locations = [
    { lat: 14.5995, lng: 120.9842, title: "Manila" }, // Example location
];

// Initialize the maps
function initMap() {
    // Get route data from the table to center the map properly
    const dispatchRows = document.querySelectorAll('.dispatch-row');
    let centerLat = 39.8283; // Default center of USA
    let centerLng = -98.5795;
    
    if (dispatchRows.length > 0) {
        // Calculate center based on actual route data
        let totalLat = 0;
        let totalLng = 0;
        let validCoordinates = 0;
        
        dispatchRows.forEach(row => {
            const lat = parseFloat(row.getAttribute('data-lat'));
            const lng = parseFloat(row.getAttribute('data-lng'));
            if (lat && lng) {
                totalLat += lat;
                totalLng += lng;
                validCoordinates++;
            }
        });
        
        if (validCoordinates > 0) {
            centerLat = totalLat / validCoordinates;
            centerLng = totalLng / validCoordinates;
        }
    }

    // Main map initialization (for desktop)
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: centerLat, lng: centerLng },
        zoom: 4, // Start with a wider view to show all routes
        styles: [
            {
                featureType: "poi",
                elementType: "labels",
                stylers: [{ visibility: "off" }]
            },
            {
                featureType: "transit",
                elementType: "labels",
                stylers: [{ visibility: "off" }]
            }
        ]
    });

    // Initialize directions service
    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer({
        suppressMarkers: true, // We'll use our custom markers
        polylineOptions: {
            strokeColor: '#3B82F6',
            strokeOpacity: 0.8,
            strokeWeight: 4
        }
    });

    // Add markers for desktop map based on actual route data
    const routeCoordinates = [];
    dispatchRows.forEach(row => {
        const route = row.getAttribute('data-route');
        const address = row.getAttribute('data-address');
        const lat = parseFloat(row.getAttribute('data-lat'));
        const lng = parseFloat(row.getAttribute('data-lng'));
        
        if (lat && lng) {
            const marker = new google.maps.Marker({
                position: { lat, lng },
                map: map,
                title: `Route ${route}: ${address}`,
                label: route,
                icon: {
                    url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                        <svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="20" cy="20" r="18" fill="#3B82F6" stroke="#1E40AF" stroke-width="2"/>
                            <text x="20" y="25" text-anchor="middle" fill="white" font-family="Arial" font-size="12" font-weight="bold">${route}</text>
                        </svg>
                    `),
                    scaledSize: new google.maps.Size(40, 40),
                    anchor: new google.maps.Point(20, 20)
                }
            });
            
            markers.push(marker);
            markersByRoute[route] = marker; // Store marker by route for global access
            routeCoordinates.push({ route, position: { lat, lng }, address });
            
            // Add info window
            const infoWindow = new google.maps.InfoWindow({
                content: `
                    <div class="p-2">
                        <h3 class="font-semibold text-gray-800">Route ${route}</h3>
                        <p class="text-sm text-gray-600">${address}</p>
                    </div>
                `
            });
            
            marker.addListener('click', () => {
                infoWindow.open(map, marker);
            });
        }
    });
    
    // Draw route path connecting all locations
    if (routeCoordinates.length > 1) {
        drawRoutePath(routeCoordinates);
    }

    // Initialize address hover functionality
    initializeAddressHover();
}

// Draw route path between locations
function drawRoutePath(routeCoordinates) {
    // Sort by route number for logical order
    routeCoordinates.sort((a, b) => parseInt(a.route) - parseInt(b.route));
    
    // Create polyline connecting all points
    const path = routeCoordinates.map(coord => coord.position);
    
    const polyline = new google.maps.Polyline({
        path: path,
        geodesic: true,
        strokeColor: '#3B82F6',
        strokeOpacity: 0.8,
        strokeWeight: 4,
        icons: [{
            icon: {
                path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                scale: 3,
                fillColor: '#3B82F6',
                fillOpacity: 1,
                strokeColor: '#1E40AF',
                strokeWeight: 1
            },
            offset: '50%',
            repeat: '100px'
        }]
    });
    
    polyline.setMap(map);
    polylines['main'] = polyline;
    
    // Add route info overlay
    addRouteInfoOverlay(routeCoordinates);
}

// Add route information overlay
function addRouteInfoOverlay(routeCoordinates) {
    // Find the map controls container
    const mapControls = document.querySelector('.view-controls');
    if (!mapControls) return;
    
    // Create route buttons container
    const routeButtonsContainer = document.createElement('div');
    routeButtonsContainer.className = 'flex gap-2 ml-2';
    
    // Create a compact route button
    const routeButton = document.createElement('button');
    routeButton.className = 'view-control-btn bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors';
    routeButton.innerHTML = `
        <i class="fas fa-route"></i>
        <span class="ml-1 text-xs">Route (${routeCoordinates.length})</span>
    `;
    routeButton.title = `Route Info (${routeCoordinates.length} stops)`;
    routeButton.id = 'routeInfoBtn';
    
    // Add route toggle button
    const toggleButton = document.createElement('button');
    toggleButton.className = 'view-control-btn';
    toggleButton.innerHTML = `
        <i class="fas fa-eye"></i>
        <span class="ml-1 text-xs">Hide</span>
    `;
    toggleButton.title = 'Hide Route';
    toggleButton.id = 'toggleRoute';
    
    // Add buttons to container
    routeButtonsContainer.appendChild(routeButton);
    routeButtonsContainer.appendChild(toggleButton);
    
    // Insert after map controls
    mapControls.parentNode.insertBefore(routeButtonsContainer, mapControls.nextSibling);
    
    // Toggle route visibility
    toggleButton.addEventListener('click', function() {
        const isVisible = polylines['main'].getMap() !== null;
        if (isVisible) {
            polylines['main'].setMap(null);
            this.innerHTML = '<i class="fas fa-eye-slash"></i><span class="ml-1 text-xs">Show</span>';
            this.title = 'Show Route';
        } else {
            polylines['main'].setMap(map);
            this.innerHTML = '<i class="fas fa-eye"></i><span class="ml-1 text-xs">Hide</span>';
            this.title = 'Hide Route';
        }
    });
    
    // Route info button click handler
    routeButton.addEventListener('click', function() {
        showRouteModal(routeCoordinates);
    });
}

// Show route modal
function showRouteModal(routeCoordinates) {
    // Create modal if it doesn't exist
    let modal = document.getElementById('routeModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'routeModal';
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white rounded-lg shadow-xl p-6 w-[500px] max-w-[90vw]">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">Dispatch Route Details</h3>
                    <button id="closeRouteModal" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div id="routeModalContent" class="space-y-4">
                    <!-- Content will be populated here -->
                </div>
                <div class="flex justify-end gap-2 mt-6">
                    <button id="exportRoute" class="px-4 py-2 text-sm text-white bg-blue-500 hover:bg-blue-600 rounded transition-colors">
                        <i class="fas fa-download mr-2"></i>Export Route
                    </button>
                    <button id="optimizeRoute" class="px-4 py-2 text-sm text-white bg-green-500 hover:bg-green-600 rounded transition-colors">
                        <i class="fas fa-route mr-2"></i>Optimize Route
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        
        // Close modal functionality
        document.getElementById('closeRouteModal').addEventListener('click', function() {
            modal.classList.add('hidden');
        });
        
        // Close modal when clicking outside
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.classList.add('hidden');
            }
        });
    }
    
    // Populate modal content
    const content = document.getElementById('routeModalContent');
    content.innerHTML = `
        <div class="grid grid-cols-2 gap-4 mb-4">
            <div class="bg-gray-50 p-3 rounded-lg">
                <div class="text-sm font-medium text-gray-600">Total Stops</div>
                <div class="text-2xl font-bold text-gray-800">${routeCoordinates.length}</div>
            </div>
            <div class="bg-gray-50 p-3 rounded-lg">
                <div class="text-sm font-medium text-gray-600">Route Order</div>
                <div class="text-sm font-semibold text-gray-800">${routeCoordinates.map(c => c.route).join(' → ')}</div>
            </div>
        </div>
        <div class="space-y-2">
            <h4 class="font-medium text-gray-800">Route Stops:</h4>
            ${routeCoordinates.map((coord, index) => `
                <div class="flex items-center p-2 bg-gray-50 rounded-lg">
                    <div class="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold mr-3">
                        ${coord.route}
                    </div>
                    <div class="flex-1">
                        <div class="font-medium text-gray-800">${coord.address}</div>
                        <div class="text-sm text-gray-600">Stop ${index + 1}</div>
                    </div>
                </div>
            `).join('')}
        </div>
    `;
    
    // Show modal
    modal.classList.remove('hidden');
}

// Initialize address hover functionality
function initializeAddressHover() {
    const addressCells = document.querySelectorAll('.address-cell');
    
    addressCells.forEach(cell => {
        // Show tooltip on hover
        cell.addEventListener('mouseenter', function() {
            const address = this.getAttribute('data-address');
            const route = this.getAttribute('data-route');
            
            // Create tooltip
            const tooltip = document.createElement('div');
            tooltip.className = 'fixed z-50 px-3 py-2 bg-gray-900 text-white text-sm rounded-lg shadow-lg pointer-events-none';
            tooltip.innerHTML = `
                <div class="font-semibold">Route ${route}</div>
                <div>${address}</div>
                <div class="text-xs text-gray-300 mt-1">Click to highlight on map</div>
            `;
            tooltip.id = 'address-tooltip';
            document.body.appendChild(tooltip);
            
            // Position tooltip
            const rect = this.getBoundingClientRect();
            tooltip.style.left = rect.left + 'px';
            tooltip.style.top = (rect.top - tooltip.offsetHeight - 10) + 'px';
            
            // Highlight marker on map
            if (markersByRoute[route]) {
                markersByRoute[route].setAnimation(google.maps.Animation.BOUNCE);
                map.panTo(markersByRoute[route].getPosition());
                map.setZoom(15);
            }
        });
        
        cell.addEventListener('mouseleave', function() {
            const route = this.getAttribute('data-route');
            
            // Remove tooltip
            const tooltip = document.getElementById('address-tooltip');
            if (tooltip) {
                tooltip.remove();
            }
            
            // Stop marker animation
            if (markersByRoute[route]) {
                markersByRoute[route].setAnimation(null);
            }
        });
        
        // Click to center map on location
        cell.addEventListener('click', function() {
            const route = this.getAttribute('data-route');
            if (markersByRoute[route]) {
                map.panTo(markersByRoute[route].getPosition());
                map.setZoom(16);
                
                // Show info window
                const infoWindow = new google.maps.InfoWindow({
                    content: `
                        <div class="p-3">
                            <h3 class="font-semibold text-gray-800">Route ${route}</h3>
                            <p class="text-sm text-gray-600">${this.getAttribute('data-address')}</p>
                            <div class="mt-2 text-xs text-gray-500">
                                <div>Team: ${this.closest('tr').querySelector('td:nth-child(11)').textContent}</div>
                                <div>Status: ${this.closest('tr').querySelector('td:nth-child(12) span').textContent}</div>
                            </div>
                        </div>
                    `
                });
                infoWindow.open(map, markersByRoute[route]);
            }
        });
    });
}

// Function to initialize mobile map
function initializeMobileMap() {
    if (!mobileMap) {
        // Get route data for mobile map centering
        const dispatchRows = document.querySelectorAll('.dispatch-row');
        let centerLat = 39.8283; // Default center of USA
        let centerLng = -98.5795;
        
        if (dispatchRows.length > 0) {
            let totalLat = 0;
            let totalLng = 0;
            let validCoordinates = 0;
            
            dispatchRows.forEach(row => {
                const lat = parseFloat(row.getAttribute('data-lat'));
                const lng = parseFloat(row.getAttribute('data-lng'));
                if (lat && lng) {
                    totalLat += lat;
                    totalLng += lng;
                    validCoordinates++;
                }
            });
            
            if (validCoordinates > 0) {
                centerLat = totalLat / validCoordinates;
                centerLng = totalLng / validCoordinates;
            }
        }

        mobileMap = new google.maps.Map(document.getElementById('mobileMapContainer'), {
            center: { lat: centerLat, lng: centerLng },
            zoom: 4,
            styles: [
                {
                    featureType: "poi",
                    elementType: "labels",
                    stylers: [{ visibility: "off" }]
                }
            ]
        });

        // Add markers for mobile map based on actual route data
        dispatchRows.forEach(row => {
            const route = row.getAttribute('data-route');
            const address = row.getAttribute('data-address');
            const lat = parseFloat(row.getAttribute('data-lat'));
            const lng = parseFloat(row.getAttribute('data-lng'));
            
            if (lat && lng) {
                const mobileMarker = new google.maps.Marker({
                    position: { lat, lng },
                    map: mobileMap,
                    title: `Route ${route}: ${address}`,
                    label: route,
                    icon: {
                        url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                            <svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="20" cy="20" r="18" fill="#3B82F6" stroke="#1E40AF" stroke-width="2"/>
                                <text x="20" y="25" text-anchor="middle" fill="white" font-family="Arial" font-size="12" font-weight="bold">${route}</text>
                            </svg>
                        `),
                        scaledSize: new google.maps.Size(40, 40),
                        anchor: new google.maps.Point(20, 20)
                    }
                });
                mobileMarkers.push(mobileMarker);
            }
        });
    }
}

// View Control Handlers
document.addEventListener('DOMContentLoaded', function() {
    const mapContainer = document.getElementById('mapContainer');
    const splitMapContainer = document.getElementById('splitMapContainer');
    const contentContainer = document.getElementById('contentContainer');
    const tableContainer = document.getElementById('tableContainer');
    const mapElement = document.getElementById('map');
    const mobileMapModal = document.getElementById('mobileMapModal');
    const mobileMapBtn = document.getElementById('mobileMapBtn');
    const closeMobileMapModal = document.getElementById('closeMobileMapModal');

    const hideMapBtn = document.getElementById('hideMapBtn');
    const listViewBtn = document.getElementById('listViewBtn');
    const splitViewBtn = document.getElementById('splitViewBtn');
    const fullMapBtn = document.getElementById('fullMapBtn');

    let currentView = 'hidden'; // Start with hidden view

    // Mobile Map Modal Controls
    mobileMapBtn.addEventListener('click', () => {
        mobileMapModal.style.display = 'flex';
        // Initialize mobile map if not already done
        initializeMobileMap();
        // Trigger resize to ensure mobile map renders correctly
        setTimeout(() => {
            google.maps.event.trigger(mobileMap, 'resize');
            // Center on actual route data
            const dispatchRows = document.querySelectorAll('.dispatch-row');
            if (dispatchRows.length > 0) {
                let totalLat = 0;
                let totalLng = 0;
                let validCoordinates = 0;
                
                dispatchRows.forEach(row => {
                    const lat = parseFloat(row.getAttribute('data-lat'));
                    const lng = parseFloat(row.getAttribute('data-lng'));
                    if (lat && lng) {
                        totalLat += lat;
                        totalLng += lng;
                        validCoordinates++;
                    }
                });
                
                if (validCoordinates > 0) {
                    mobileMap.setCenter({ 
                        lat: totalLat / validCoordinates, 
                        lng: totalLng / validCoordinates 
                    });
                }
            }
        }, 100);
    });

    closeMobileMapModal.addEventListener('click', () => {
        mobileMapModal.style.display = 'none';
    });

    // Close modal when clicking outside
    mobileMapModal.addEventListener('click', (e) => {
        if (e.target === mobileMapModal) {
            mobileMapModal.style.display = 'none';
        }
    });

    // Helper function to reset all buttons
    function resetButtons() {
        [hideMapBtn, listViewBtn, splitViewBtn, fullMapBtn].forEach(btn => {
            btn.classList.remove('active');
        });
    }

    // Helper function to reset containers
    function resetContainers() {
        mapContainer.classList.remove('hidden', 'full');
        contentContainer.classList.remove('split-view');
        splitMapContainer.classList.add('hidden');
        tableContainer.classList.remove('w-1/2');
        tableContainer.classList.add('w-full');
        mapElement.style.display = 'block'; // Ensure map is visible by default
    }

    // Desktop view handlers
    hideMapBtn.addEventListener('click', () => {
        if (window.innerWidth < 768) return; // Ignore on mobile
        resetButtons();
        resetContainers();
        hideMapBtn.classList.add('active');
        mapContainer.classList.add('hidden');
        mapElement.style.display = 'none'; // Hide the map element
        if (currentView === 'split') {
            mapContainer.appendChild(mapElement);
        }
        currentView = 'hidden';
    });

    listViewBtn.addEventListener('click', () => {
        if (window.innerWidth < 768) return; // Ignore on mobile
        resetButtons();
        resetContainers();
        listViewBtn.classList.add('active');
        mapContainer.classList.remove('hidden');
        mapElement.style.display = 'block'; // Show the map element
        if (currentView === 'split') {
            mapContainer.appendChild(mapElement);
        }
        currentView = 'list';
        // Trigger resize after a small delay to ensure the map is visible
        setTimeout(() => {
            google.maps.event.trigger(map, 'resize');
            // Center on actual route data
            const dispatchRows = document.querySelectorAll('.dispatch-row');
            if (dispatchRows.length > 0) {
                let totalLat = 0;
                let totalLng = 0;
                let validCoordinates = 0;
                
                dispatchRows.forEach(row => {
                    const lat = parseFloat(row.getAttribute('data-lat'));
                    const lng = parseFloat(row.getAttribute('data-lng'));
                    if (lat && lng) {
                        totalLat += lat;
                        totalLng += lng;
                        validCoordinates++;
                    }
                });
                
                if (validCoordinates > 0) {
                    map.setCenter({ 
                        lat: totalLat / validCoordinates, 
                        lng: totalLng / validCoordinates 
                    });
                }
            }
        }, 100);
    });

    splitViewBtn.addEventListener('click', () => {
        if (window.innerWidth < 768) return; // Ignore on mobile
        resetButtons();
        resetContainers();
        splitViewBtn.classList.add('active');
        mapContainer.classList.add('hidden');
        splitMapContainer.classList.remove('hidden');
        contentContainer.classList.add('split-view');
        splitMapContainer.appendChild(mapElement);
        currentView = 'split';
        google.maps.event.trigger(map, 'resize');
    });

    fullMapBtn.addEventListener('click', () => {
        if (window.innerWidth < 768) return; // Ignore on mobile
        resetButtons();
        resetContainers();
        fullMapBtn.classList.add('active');
        mapContainer.classList.add('full');
        if (currentView === 'split') {
            mapContainer.appendChild(mapElement);
        }
        currentView = 'full';
        google.maps.event.trigger(map, 'resize');
    });

    // Initialize with hidden view on desktop (map hidden by default)
    if (window.innerWidth >= 768) {
        hideMapBtn.click();
    }
}); 